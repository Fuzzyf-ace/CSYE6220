package com.daiming.homework2.Controller;

import com.daiming.homework2.Service.CsvService;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "CsvServlet", value="/getCsv.csv")
public class CsvServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CsvService csvService = new CsvService();
        String fileName = request.getParameter("file_name");
        HttpSession session = request.getSession();
        session.setAttribute("file_name", fileName);
        session.setAttribute("resultSet", csvService.getCsv(fileName));
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/JSPFile/csvView.jsp");
        requestDispatcher.forward(request, response);
    }
}
