package com.daiming.homework2.Controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.*;

@WebServlet(name = "CartServlet", value = "/shopping/cart")
public class CartServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("../WEB-INF/JSPFile/shopping/cart.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        List<String> cart = (LinkedList<String>) session.getAttribute("cart");
        if (cart == null) {
            cart = new LinkedList<>();
        }
        String[] items = request.getParameterValues("item");

        if (request.getParameter("action") != null) {
            if (request.getParameter("action").equals("doDelete")) {
                for (int i = 0; i < items.length; i++) {
                    cart.remove(items[i]);
//                    System.out.println(items[i]);
                }
                System.out.println(cart);
            } else {
                for (int i = 0; i < items.length; i++) {
                    cart.add(items[i]);
//                    System.out.println(items[i]);
                }
//                System.out.println(cart);
            }
        }
        session.setAttribute("cart", cart);

        RequestDispatcher requestDispatcher = request.getRequestDispatcher("../WEB-INF/JSPFile/shopping/cart.jsp");
        requestDispatcher.forward(request, response);
    }

//    @Override
//    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        HttpSession session = request.getSession(false);
//        List<String> cart = (List<String>) session.getAttribute("cart");
//        String[] deleteItems = request.getParameterValues("delete_item");
//
////        cart.remove(cart.get(0));
//
//        for (String deleteItem : deleteItems) {
////            cart.remove(deleteItem);
//        }
//        session.setAttribute("cart", null);
//
//        RequestDispatcher requestDispatcher = request.getRequestDispatcher("/shopping/cart");
//
//        requestDispatcher.forward(request, response);
//    }
}
