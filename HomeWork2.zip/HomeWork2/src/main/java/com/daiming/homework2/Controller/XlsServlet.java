package com.daiming.homework2.Controller;

import com.daiming.homework2.Service.XlsService;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "XlsServlet", value = "/getXls.xls")
public class XlsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        XlsService xlsService = new XlsService();
        String fileName = request.getParameter("file_name");
        HttpSession session = request.getSession();

        session.setAttribute("file_name", fileName);
        session.setAttribute(fileName, xlsService.getXls(fileName));
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/JSPFile/xlsView.jsp");
        requestDispatcher.forward(request, response);
    }
}
