package com.daiming.homework2.Service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;


import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;

public class XlsService {
    public final URL fileUrl = this.getClass().getResource("/file");

    public HSSFWorkbook getXls(String fileName) {
        HSSFWorkbook hssfWorkbook = null;
        try {
            FileInputStream xlsFile = new FileInputStream(fileUrl.getPath() + fileName + ".xls");
            hssfWorkbook = new HSSFWorkbook(xlsFile);
            xlsFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hssfWorkbook;
    }
}
