package com.daiming.homework2;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.net.URL;

@Configuration
@EnableWebMvc
public class ApplicationConfig {

}
