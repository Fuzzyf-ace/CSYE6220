package com.daiming.homework2.Service;

import org.springframework.stereotype.Service;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CsvService {

    public final URL fileUrl = this.getClass().getResource("/file");

    public ResultSet getCsv(String fileName) {
        ResultSet resultSet = null;
        try {
            Class.forName("org.relique.jdbc.csv.CsvDriver");
            Connection connection = DriverManager.getConnection("jdbc:relique:csv:" + fileUrl.getPath());
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM " + fileName);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }
}
