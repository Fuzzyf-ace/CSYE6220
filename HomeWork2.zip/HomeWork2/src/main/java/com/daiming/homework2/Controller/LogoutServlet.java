package com.daiming.homework2.Controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

@WebServlet(name = "LoginServlet", value = "/logout")
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        response.setContentType("text/html");
        response.getWriter().println("Successfully logout!");
        response.getWriter().println("<p><a href=/>Back to homework2</a></p>");
    }
}
